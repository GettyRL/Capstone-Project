import Specials from './Specials.js';
import pizza from './pizza.png';
import Testimonials from './Testimonials.js';
import About from './About.js';
import Main from './Main.js';

function Home() {
  return (
    <>

   
    <Main/>
    <Specials/>
    <Testimonials/>
    <About/>
    


    </>
  );
}

export default Home;
